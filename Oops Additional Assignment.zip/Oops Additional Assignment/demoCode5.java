
import java.util.Scanner;

public class demoCode5 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter price of item: ");
        double price = sc.nextDouble();

        System.out.print("Enter quantity: ");
        int quantity = sc.nextInt();

        double total = price * quantity;

        System.out.printf("Total Bill = %.2f%n", total);

        sc.close();
    }
}
