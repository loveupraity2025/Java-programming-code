public class InnerStaticAnonymousClassDemo {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000);

        // Inner class object
        BankAccount.Transaction t = account.new Transaction();
        t.deposit(500);

        // Static nested class
        BankAccount.Receipt.printReceipt();

        // Anonymous class implementing Notifier
        account.sendNotification(new Notifier() {
            public void notifyUser(String message) {
                System.out.println("Notification: " + message);
            }
        });
    }
}

interface Notifier {
    void notifyUser(String message);
}

class BankAccount {
    private double balance;

    BankAccount(double balance) {
        this.balance = balance;
    }

    // Inner class accesses and changes the private balance field
    class Transaction {
        void deposit(double amount) {
            if (amount > 0) {
                balance = balance + amount;
                System.out.println("Deposited = " + amount);
                System.out.println("New Balance = " + balance);
            } else {
                System.out.println("Amount must be positive.");
            }
        }
    }

    // Static nested class works without a BankAccount object
    static class Receipt {
        static void printReceipt() {
            System.out.println("Receipt Printed Successfully");
        }
    }

    void sendNotification(Notifier notifier) {
        notifier.notifyUser("Account Updated Successfully");
    }
}