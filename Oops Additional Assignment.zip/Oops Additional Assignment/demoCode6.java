
import java.util.Scanner;

public class demoCode6 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter temperature in Celsius: ");
        double c = sc.nextDouble();

        double f = (c * 9 / 5) + 32;

        System.out.printf("%.2f °C = %.2f °F%n", c, f);

        sc.close();
    }
}
