public class InterfaceSwitchableDemo {
    public static void main(String[] args) {
        Switchable[] arr = {
            new Light(),
            new AC(),
            new Fan(),
            new Television()
        };

        for (Switchable s : arr) {
            s.turnOn();
            s.turnOff();
            System.out.println();
        }
    }
}

interface Switchable {
    void turnOn();
    void turnOff();
}

class Light implements Switchable {
    public void turnOn() {
        System.out.println("Light is ON");
    }

    public void turnOff() {
        System.out.println("Light is OFF");
    }
}

class AC implements Switchable {
    public void turnOn() {
        System.out.println("AC is ON");
    }

    public void turnOff() {
        System.out.println("AC is OFF");
    }
}

class Fan implements Switchable {
    public void turnOn() {
        System.out.println("Fan is ON");
    }

    public void turnOff() {
        System.out.println("Fan is OFF");
    }
}

class Television implements Switchable {
    public void turnOn() {
        System.out.println("Television is ON");
    }

    public void turnOff() {
        System.out.println("Television is OFF");
    }
}