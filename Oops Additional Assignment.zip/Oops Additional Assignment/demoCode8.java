
import java.util.Scanner;

public class demoCode8 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter total number of days: ");
        int totalDays = sc.nextInt();

        int years = totalDays / 365;
        int remaining = totalDays % 365;

        int weeks = remaining / 7;
        int days = remaining % 7;

        System.out.println("Years          = " + years);
        System.out.println("Weeks          = " + weeks);
        System.out.println("Remaining days = " + days);

        sc.close();
    }
}
