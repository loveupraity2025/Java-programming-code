
abstract class Payment {
    protected double amount;

    Payment(double amount) {
        this.amount = amount;
    }

    // Concrete method
    void printReceipt() {
        System.out.println("Receipt: Payment of Rs. " + amount + " completed.");
    }

    // Abstract method
    abstract void pay();
}

class CreditCardPayment extends Payment {
    CreditCardPayment(double amount) {
        super(amount);
    }

    @Override
    void pay() {
        System.out.println("Paying Rs. " + amount + " using Credit Card (PIN/OTP verified).");
    }
}

class UpiPayment extends Payment {
    UpiPayment(double amount) {
        super(amount);
    }

    @Override
    void pay() {
        System.out.println("Paying Rs. " + amount + " using UPI (scan & pay).");
    }
}

class CashPayment extends Payment {
    CashPayment(double amount) {
        super(amount);
    }

    @Override
    void pay() {
        System.out.println("Paying Rs. " + amount + " in Cash at the counter.");
    }
}

public class demoCode19 {
    public static void main(String[] args) {

        Payment[] payments = {
            new CreditCardPayment(2500.50),
            new UpiPayment(799.00),
            new CashPayment(150.75)
        };

        for (Payment p : payments) {
            p.pay();
            p.printReceipt();
            System.out.println("----------------------------");
        }
    }
}
