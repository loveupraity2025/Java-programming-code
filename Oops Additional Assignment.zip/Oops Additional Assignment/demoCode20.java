
interface Switchable {
    void turnOn();
    void turnOff();
}

class Light implements Switchable {
    public void turnOn() {
        System.out.println("Light is ON - room is bright.");
    }

    public void turnOff() {
        System.out.println("Light is OFF - room is dark.");
    }
}

class AC implements Switchable {
    public void turnOn() {
        System.out.println("AC is ON - cooling to 24°C.");
    }

    public void turnOff() {
        System.out.println("AC is OFF - cooling stopped.");
    }
}

class Fan implements Switchable {
    public void turnOn() {
        System.out.println("Fan is ON - blades spinning.");
    }

    public void turnOff() {
        System.out.println("Fan is OFF - blades slowing down.");
    }
}

// Added later
class Heater implements Switchable {
    public void turnOn() {
        System.out.println("Heater is ON - warming the room.");
    }

    public void turnOff() {
        System.out.println("Heater is OFF - heating stopped.");
    }
}

public class demoCode20 {
    public static void main(String[] args) {

        Switchable[] devices = {
            new Light(),
            new AC(),
            new Fan(),
            new Heater()
        };

        // Same loop for all devices
        for (Switchable d : devices) {
            d.turnOn();
            d.turnOff();
            System.out.println("----------------------------");
        }
    }
}
