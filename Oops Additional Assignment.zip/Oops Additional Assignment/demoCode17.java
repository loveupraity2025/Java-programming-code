
import java.util.Scanner;

public class demoCode17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter n: ");
        int n = sc.nextInt();

        if (n <= 0) {
            System.out.println("n must be greater than 0.");
            sc.close();
            return;
        }

        int[] arr = new int[n];
        int sum = 0;

        System.out.println("Enter " + n + " numbers:");

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
            sum += arr[i];
        }

        double average = (double) sum / n;

        System.out.println("Sum = " + sum);
        System.out.printf("Average = %.2f%n", average);

        sc.close();
    }
}
