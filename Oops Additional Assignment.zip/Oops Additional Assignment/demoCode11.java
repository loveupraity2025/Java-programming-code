
import java.util.Scanner;

public class demoCode11 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String s = sc.nextLine();

        if (s.isEmpty()) {
            System.out.println("Empty string entered.");
        } else {
            System.out.println("First character = " + s.charAt(0));

            System.out.println("Last character  = " + s.charAt(s.length() - 1));

            // Position 3 = 3rd character (index 2)
            if (s.length() >= 3) {
                System.out.println("Character at position 3 = " + s.charAt(2));
            } else {
                System.out.println("String has fewer than 3 characters.");
            }
        }

        sc.close();
    }
}
