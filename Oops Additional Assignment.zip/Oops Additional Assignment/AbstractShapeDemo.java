public class AbstractShapeDemo {
    public static void main(String[] args) {
        Shape[] arr = {
            new Circle(5),
            new Rectangle(4, 6),
            new Triangle(3, 8)
        };

        for (Shape s : arr) {
            s.display();
            System.out.println("Area = " + s.calculateArea());
            System.out.println();
        }
    }
}

abstract class Shape {
    String name;

    Shape(String name) {
        this.name = name;
    }

    void display() {
        System.out.println("Shape = " + name);
    }

    abstract double calculateArea();
}

class Circle extends Shape {
    double radius;

    Circle(double radius) {
        super("Circle");
        this.radius = radius;
    }

    double calculateArea() {
        return Math.PI * radius * radius;
    }
}

class Rectangle extends Shape {
    double length, breadth;

    Rectangle(double length, double breadth) {
        super("Rectangle");
        this.length = length;
        this.breadth = breadth;
    }

    double calculateArea() {
        return length * breadth;
    }
}

class Triangle extends Shape {
    double base, height;

    Triangle(double base, double height) {
        super("Triangle");
        this.base = base;
        this.height = height;
    }

    double calculateArea() {
        return 0.5 * base * height;
    }
}