
import java.util.Scanner;

public class demoCode15 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first name: ");
        String first = sc.next();

        System.out.print("Enter last name: ");
        String last = sc.next();

        String fullName = first + " " + last;

        String initials = Character.toUpperCase(first.charAt(0)) + "."
                        + Character.toUpperCase(last.charAt(0)) + ".";

        System.out.println("Full name = " + fullName);
        System.out.println("Initials  = " + initials);

        sc.close();
    }
}
